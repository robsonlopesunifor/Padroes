package POO;

public class Cachorro 
{
	public String nome = "Betovem";
	
	Cachorro()
	{
		System.out.println(nome);
	}
}
